package com.epf.RentManager.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.epf.RentManager.exception.DaoException;
import com.epf.RentManager.model.Client;
import com.epf.RentManager.model.Reservation;
import com.epf.RentManager.model.Vehicule;
import com.epf.RentManager.persistence.ConnectionManager;

public class ReservationDao {

	private static ReservationDao instance = null;
	private ReservationDao() {}
	public static ReservationDao getInstance() {
		if(instance == null) {
			instance = new ReservationDao();
		}
		return instance;
	}
	
	private static final String CREATE_RESERVATION_QUERY = "INSERT INTO Reservation(client_id, vehicule_id, debut, fin) VALUES(?, ?, ?, ?);";
	private static final String DELETE_RESERVATION_QUERY = "DELETE FROM Reservation WHERE id=?;";
	private static final String FIND_RESERVATIONS_BY_CLIENT_QUERY = "SELECT id, vehicule_id, debut, fin FROM Reservation WHERE client_id=?;";
	private static final String FIND_RESERVATIONS_BY_VEHICLE_QUERY = "SELECT id, client_id, debut, fin FROM Reservation WHERE vehicule_id=?;";
	private static final String FIND_RESERVATIONS_QUERY = "SELECT id, client_id, vehicule_id, debut, fin FROM Reservation;";
		
	
	public long create(Reservation reservation) throws DaoException {
		try (Connection conn = ConnectionManager.getConnection();
				PreparedStatement statement = conn.prepareStatement(CREATE_RESERVATION_QUERY);)
				{
				statement.setInt(1, reservation.getClient_id());
				statement.setInt(2, reservation.getVehicule_id());
				statement.setDate(3, reservation.getDebut());
				statement.setDate(4, reservation.getFin());
				
				long result = statement.executeUpdate();
				return result;
			} catch(SQLException e) {
				throw new DaoException("Erreur lors de la création : " + e.getMessage());
			}
	}
	
	public long delete(int id) throws DaoException {
		try (Connection conn = ConnectionManager.getConnection();
				PreparedStatement statement = conn.prepareStatement(DELETE_RESERVATION_QUERY);){
			
			statement.setInt(1, id);
			
			long result = statement.executeUpdate();
			return result;
			
		} catch (SQLException e) {
			throw new DaoException("Erreur lors de la suppression : " + e.getMessage());
		} 
	}

	
	public void findResaByClientId(int clientId) throws DaoException {
		try (Connection conn = ConnectionManager.getConnection();
				PreparedStatement statement = conn.prepareStatement(FIND_RESERVATIONS_BY_CLIENT_QUERY);) {
			
			statement.setInt(1, clientId);
			ResultSet resultSet2 = statement.executeQuery();
			
			while(resultSet2.next()) {
				Reservation r = new Reservation();
				
				r.setId(resultSet2.getInt(1));
				r.setVehicule_id(resultSet2.getInt(2));
				r.setDebut(resultSet2.getDate(3));
				r.setFin(resultSet2.getDate(4));
				r.setClient_id(clientId);
				System.out.println(r.select_client());
			}
			
		} catch(SQLException e) {
			throw new DaoException("Erreur lors du SELECT de la réservation : " + e.getMessage());
		}
	}
	
	public void findResaByVehicleId(int vehiculeId) throws DaoException {
		try (Connection conn = ConnectionManager.getConnection();
				PreparedStatement statement = conn.prepareStatement(FIND_RESERVATIONS_BY_VEHICLE_QUERY);) {
			
			statement.setInt(1, vehiculeId);
			ResultSet resultSet2 = statement.executeQuery();
			
			while(resultSet2.next()) {
				
				Reservation r = new Reservation();
				
				r.setId(resultSet2.getInt(1));
				r.setClient_id(resultSet2.getInt(2));
				r.setDebut(resultSet2.getDate(3));
				r.setFin(resultSet2.getDate(4));
				r.setVehicule_id(vehiculeId);
				System.out.println(r.select_vehicule());
			}
			
		} catch(SQLException e) {
			throw new DaoException("Erreur lors du SELECT de la réservation : " + e.getMessage());
		}
	}

	public List<Reservation> findAll() throws DaoException {
		List<Reservation> resultList = new ArrayList<>();
		try (Connection conn = ConnectionManager.getConnection();
				PreparedStatement statement = conn.prepareStatement(FIND_RESERVATIONS_QUERY);)
		{
			ResultSet resultSet = statement.executeQuery();
			
			while(resultSet.next()) {
				Client cli = new Client();
				cli.setId(resultSet.getInt(2));
				cli.setPrenom(resultSet.getString(3));
				cli.setNom(resultSet.getString(4));
				
				Vehicule veh = new Vehicule();
				veh.setId(resultSet.getInt(5));
				veh.setConstructeur(resultSet.getString(6));
				veh.setModele(resultSet.getString(7));
			
				Reservation reser = new Reservation(resultSet.getInt(1), cli, veh, resultSet.getDate(8), resultSet.getDate(9));
			
				resultList.add(reser);
			}
			return resultList;
			
		} catch(SQLException e) {
			// e.printStackTrace(); Pour comprendre l'erreur
			throw new DaoException("Erreur lors du SELECT : " + e.getMessage());
		}
	}
}
