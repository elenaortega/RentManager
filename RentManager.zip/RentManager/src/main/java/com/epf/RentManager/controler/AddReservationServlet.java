package com.epf.RentManager.controler;

import java.io.IOException;
import java.sql.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epf.RentManager.exception.ServiceException;
import com.epf.RentManager.model.Client;
import com.epf.RentManager.model.Reservation;
import com.epf.RentManager.model.Vehicule;
import com.epf.RentManager.service.ClientService;
import com.epf.RentManager.service.ReservationService;
import com.epf.RentManager.service.VehiculeService;

@WebServlet("/rents/create")

public class AddReservationServlet extends HttpServlet {
	ReservationService reservationService = ReservationService.getInstance();
	ClientService clientService = ClientService.getInstance();
	VehiculeService vehiculeService = VehiculeService.getInstance();

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/rents/create.jsp");
		
		try {
			request.setAttribute("list_clients", clientService.findAll());
			request.setAttribute("list_vehicules", vehiculeService.findAll());
		} catch (ServiceException e) {
			request.setAttribute("errorMessage", "Une erreur est survenue :" + e.getMessage());
		}
			
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int client_id = Integer.parseInt(request.getParameter("client"));
		int vehicule_id = Integer.parseInt(request.getParameter("vehicule"));
		Date debut = Date.valueOf(request.getParameter("debut"));
		Date fin = Date.valueOf(request.getParameter("fin"));
		
		RequestDispatcher dispatcher;
		
		try {
		Reservation newReservation = new Reservation();
		List<Client> list = clientService.findAll();
		
		for(Client client : list) {
			if (client.getId() == client_id) {
				newReservation.setClient(client);
			}
		}
		
		List<Vehicule> list2 = vehiculeService.findAll();
		
		for(Vehicule vehicule : list2) {
			if(vehicule.getId() == vehicule_id) {
				newReservation.setVehicule(vehicule);
			}
		}

		newReservation.setDebut(debut);
		newReservation.setFin(fin);

			reservationService.create(newReservation);
			response.sendRedirect(request.getContextPath()+ "/rents");
		} catch (ServiceException e) {
			request.setAttribute("errorMessage", "Une erreur est survenue :" + e.getMessage());
			
			dispatcher = request.getRequestDispatcher("/WEB-INF/views/rents/create.jsp");
			dispatcher.forward(request, response);
		}
	}
}
