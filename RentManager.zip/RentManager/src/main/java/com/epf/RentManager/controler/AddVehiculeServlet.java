package com.epf.RentManager.controler;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epf.RentManager.exception.ServiceException;
import com.epf.RentManager.model.Vehicule;
import com.epf.RentManager.service.VehiculeService;

@WebServlet("/cars/create")

public class AddVehiculeServlet extends HttpServlet{
	VehiculeService vehiculeService = VehiculeService.getInstance();

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/cars/create.jsp");

		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String constructeur = request.getParameter("constructeur");
		String modele = request.getParameter("modele");
		byte nb_places = (byte) Integer.parseInt(request.getParameter("nb_places"));

		Vehicule newCar = new Vehicule();
		newCar.setConstructeur(constructeur);
		newCar.setModele(modele);
		newCar.setNb_places(nb_places);
		RequestDispatcher dispatcher;

		try {
			vehiculeService.create(newCar);
			response.sendRedirect(request.getContextPath()+ "/cars");
		} catch (ServiceException e) {
			request.setAttribute("errorMessage", "Une erreur est survenue :" + e.getMessage());
		
			dispatcher = request.getRequestDispatcher("/WEB-INF/views/cars/create.jsp");
			dispatcher.forward(request, response);
		}
	}
}
