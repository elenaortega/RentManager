package com.epf.RentManager.controler;

import java.sql.Date;
import java.util.List;
import java.util.Scanner;

import com.epf.RentManager.exception.ServiceException;
import com.epf.RentManager.model.Client;
import com.epf.RentManager.model.Reservation;
import com.epf.RentManager.model.Vehicule;
import com.epf.RentManager.service.ClientService;
import com.epf.RentManager.service.ReservationService;
import com.epf.RentManager.service.VehiculeService;

public class CliControler {
	
	private ClientService clientService = ClientService.getInstance();
	private VehiculeService vehiculeService = VehiculeService.getInstance();
	private ReservationService reservationService = ReservationService.getInstance();

	
	public static void main (String[] args) {
		
		CliControler cli = new CliControler();
		Scanner sc = new Scanner(System.in);
		boolean done = false;
		while(!done) {
		
			System.out.println("Liste des opérations");
			System.out.println("0 - Quitter le programme");
			System.out.println("1 - Afficher la liste des clients");
			System.out.println("2 - Ajouter un client");
			System.out.println("3 - Afficher un client avec son ID");
			System.out.println("4 - Supprimer un client avec son ID");
			System.out.println("5 - Ajouter un véhicule");
			System.out.println("6 - Afficher la liste des véhicules");
			System.out.println("7 - Afficher un véhicule avec son ID");
			System.out.println("8 - Supprimer un véhicule avec son ID");
			System.out.println("9 - Faire une réservation");
			System.out.println("10 - Afficher toutes les réservations");
			System.out.println("11 - Afficher toutes les réservations d'un client donné");
			System.out.println("12 - Afficher toutes les réservations d'un véhicule donné");
			System.out.println("13 - Supprimer une réservation");
			
			int choix = sc.nextInt();
			sc.nextLine();
			
			switch (choix) {
			case 0:
				done = true;
				break;
			case 1:
				printAllClients(cli);
				break;
			case 2:
				addClient(cli, sc);
				break;
			case 3:
				findClientByID(cli, sc);
				break;
			case 4:
				deleteClient(cli, sc);
				break;
			case 5:
				addVehicule(cli, sc);
				break;
			case 6:
				printAllVehicules(cli);
				break;
			case 7:
				findVehiculeByID(cli, sc);
				break;
			case 8:
				deleteVehicule(cli, sc);
				break;
			case 9:
				addReservation(cli, sc);
				break;
			case 10:
				printAllReservations(cli);
				break;
			case 11:
				findResaByClient (cli, sc);
				break;
			case 12:
				findResaByVehicule (cli, sc);
				break;
			case 13:
				deleteReservation (cli, sc);
			default:
				System.out.println("Vous n'avez pas choisi d'opération. Veuillez choisir une des options.");
			}
		}
		sc.close();
	}
	
	
	private static void printAllClients(CliControler cli) {
		try {
			List<Client> list = cli.clientService.findAll();
			
			for(Client client : list) {
				System.out.println(client);
			}
			
			//Alternative plus compliquée :  
			//list.stream().forEach(System.out::println);
			
		} catch (ServiceException e) {
			System.out.println("Une erreur est survenue : " + e.getMessage());
		}
	}
	
	
	private static void addClient(CliControler cli, Scanner sc) {
		Client client = new Client();
		
		System.out.println("Entrez le nom");
		client.setNom(sc.nextLine());
		System.out.println("Entrez le prénom");
		client.setPrenom(sc.nextLine());
		System.out.println("Entrez l'email");
		client.setEmail(sc.nextLine());
		while (client.getEmail().matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$") == false) {
			System.out.println("Veuillez saisir un email valide");
			client.setEmail(sc.nextLine());
		}
		System.out.println("Entrez la date de naissance au format yyyy-[m]m-[d]d");
		checkDateFormat(sc, client);
		
		try {
			cli.clientService.create(client);
		} catch (ServiceException e) {
			System.out.println("Une erreur est survenue : " + e.getMessage());
		}
	}
	
	
	private static void checkDateFormat(Scanner sc, Client client) {
		boolean verif = false;
		do {
			try {
				verif = true;
				client.setNaissance(Date.valueOf(sc.nextLine()));
			} catch (IllegalArgumentException e) {
				System.out.println("Veuillez saisir une date valide (yyyy-[m]m-[d]d)");
				verif = false;
			}
		} while (verif == false);
	}
		
	
	private static void findClientByID(CliControler cli, Scanner sc) {
		try {	
			System.out.println("Veuillez rentrer l'ID du client que vous souhaitez obtenir :");
			int ID = sc.nextInt();			
			cli.clientService.findById(ID);				
		} catch (ServiceException e) {
			System.out.println("Une erreur est survenue : " + e.getMessage());
		}
	}
	
	private static void deleteClient (CliControler cli, Scanner sc) {
		try {
			System.out.println("Veuillez rentrer l'ID du client que vous souhaitez supprimer :");
			int ID = sc.nextInt();			
			cli.clientService.delete(ID);
		} catch (ServiceException e) {
			System.out.println("Une erreur est survenue : " + e.getMessage());
		}
	}
	
	
	private static void printAllVehicules(CliControler cli) {
		try {
			List<Vehicule> list = cli.vehiculeService.findAll();
			
			for(Vehicule vehicule : list) {
				System.out.println(vehicule);
			}
			
			//Alternative plus compliquée :  
			//list.stream().forEach(System.out::println);
			
		} catch (ServiceException e) {
			System.out.println("Une erreur est survenue : " + e.getMessage());
		}
	}
	
	
	private static void addVehicule(CliControler cli, Scanner sc) {
		// TODO Auto-generated method stub
		Vehicule vehicule = new Vehicule();
		
		System.out.println("Entrez le constructeur");
		vehicule.setConstructeur(sc.nextLine());
		System.out.println("Entrez le modèle");
		vehicule.setModele(sc.nextLine());
		System.out.println("Entrez le nombre de places");
		vehicule.setNb_places(sc.nextByte());
		
		try {
			cli.vehiculeService.create(vehicule);
		} catch (ServiceException e) {
			System.out.println("Une erreur est survenue : " + e.getMessage());
		}
	}
	
	
	private static void checkDateFormat(Scanner sc, Reservation resa, char indicateur) {
		// TODO Auto-generated method stub
		boolean verif = false;
		do {
			try {
				verif = true;
				if (indicateur == 'd') {
					resa.setDebut(Date.valueOf(sc.nextLine()));
				}
				if (indicateur == 'f') {
					resa.setFin(Date.valueOf(sc.nextLine()));
				}
			} catch (IllegalArgumentException e) {
				System.out.println("Veuillez saisir une date valide (yyyy-[m]m-[d]d)");
				verif = false;
			}
		} while (verif == false);
	}
	
	
	private static void findVehiculeByID(CliControler cli, Scanner sc) {
		// TODO Auto-generated method stub
		try {	
			System.out.println("Veuillez rentrer l'ID du véhicule que vous souhaitez obtenir :");
			int ID = sc.nextInt();			
			cli.vehiculeService.findById(ID);				
		} catch (ServiceException e) {
			System.out.println("Une erreur est survenue : " + e.getMessage());
		}
	}


	private static void deleteVehicule(CliControler cli, Scanner sc) {
		// TODO Auto-generated method stub
		try {
			System.out.println("Veuillez rentrer l'ID du vehicule que vous souhaitez supprimer :");
			int ID = sc.nextInt();			
			cli.vehiculeService.delete(ID);
		} catch (ServiceException e) {
			System.out.println("Une erreur est survenue : " + e.getMessage());
		}
	}
	
	
	private static void addReservation(CliControler cli, Scanner sc) {
		// TODO Auto-generated method stub
		Reservation resa = new Reservation();
		
		System.out.println("Entrez l'identifiant du client");
		resa.setClient_id(sc.nextInt());
		System.out.println("Entrez l'identifiant du véhicule");
		resa.setVehicule_id(sc.nextInt());
		System.out.println("Entrez la date de début au format yyyy-[m]m-[d]d");
		checkDateFormat(sc, resa, 'd');
		System.out.println("Entrez la date de fin au format yyyy-[m]m-[d]d");
		checkDateFormat(sc, resa, 'f');
		try {
			cli.reservationService.create(resa);
		} catch (ServiceException e) {
			System.out.println("Une erreur est survenue :" + e.getMessage());
		} 
	}


	private static void printAllReservations(CliControler cli) {
		// TODO Auto-generated method stub
		try {
			List<Reservation> list = cli.reservationService.findAll();
			
			for(Reservation reservation : list) {
				System.out.println(reservation);
			}
			
			//Alternative plus compliquée :  
			//list.stream().forEach(System.out::println);
			
		} catch (ServiceException e) {
			System.out.println("Une erreur est survenue :" + e.getMessage());
		}
	}


	private static void findResaByVehicule(CliControler cli, Scanner sc) {
		// TODO Auto-generated method stub
		try {	
			System.out.println("Veuillez rentrer l'ID du véhicule concerné :");
			int ID = sc.nextInt();			
			cli.reservationService.findResaByVehicleId(ID);				
		} catch (ServiceException e) {
			System.out.println("Une erreur est survenue :" + e.getMessage());
		}
	}


	private static void findResaByClient(CliControler cli, Scanner sc) {
		// TODO Auto-generated method stub
		try {	
			System.out.println("Veuillez rentrer l'ID du client concerné :");
			int ID = sc.nextInt();			
			cli.reservationService.findResaByClientId(ID);				
		} catch (ServiceException e) {
			System.out.println("Une erreur est survenue :" + e.getMessage());
		}
	}
	
	
	private static void deleteReservation(CliControler cli, Scanner sc) {
		// TODO Auto-generated method stub
		try {	
			System.out.println("Veuillez rentrer l'ID de la réservation que vous souhaitez supprimer :");
			int ID = sc.nextInt();			
			cli.reservationService.delete(ID);
		} catch (ServiceException e) {
			System.out.println("Une erreur est survenue :" + e.getMessage());
		}
	}
}
