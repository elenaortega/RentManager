package com.epf.RentManager.service;

import java.util.List;
import java.util.Optional;

import com.epf.RentManager.exception.DaoException;
import com.epf.RentManager.exception.ServiceException;
import com.epf.RentManager.model.Vehicule;
import com.epf.RentManager.dao.VehiculeDao;

public class VehiculeService {

	private VehiculeDao vehiculedao;
	public static VehiculeService instance;
	
	private VehiculeService() {
		this.vehiculedao = VehiculeDao.getInstance();
	}
	
	public static VehiculeService getInstance() {
		if (instance == null) {
			instance = new VehiculeService();
		}
		
		return instance;
	}
	
	
	public long create(com.epf.RentManager.model.Vehicule vehicule) throws ServiceException {
		// TODO: créer un véhicule
		
		if(vehicule.getConstructeur().equals("") == true) {
			throw new ServiceException("Le champ constructeur est vide."); //ça ne marche pas
		}
		if(vehicule.getModele().equals("") == true) {
			throw new ServiceException("Le champ modèle est vide."); //ça ne marche pas
		}
		if(vehicule.getNb_places() <= 1) {
			throw new ServiceException("Le nombre de places doit être superieur à 1.");
		}
		if(vehicule.getNb_places() >= 10) {
			throw new ServiceException("Le nombre de places doit être inférieur à 10.");
		}
		
		try {
			return vehiculedao.create(vehicule);
		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
		
	}

	public Optional<Vehicule> findById(int id) throws ServiceException {
		// TODO: récupérer un véhicule par son id
		
		Optional<Vehicule> optVehicule = vehiculedao.findById(id);
		
		if(optVehicule.isPresent()) {
			Vehicule v = optVehicule.get();
			System.out.println(v);
		}else {
			System.out.println("Erreur lors du select du vehicule");
		}
		
		return optVehicule;
		
	}

	public List<Vehicule> findAll() throws ServiceException {
		// TODO: récupérer tous les clients
		
		try {
			return vehiculedao.findAll();
		} catch (DaoException e) {
			throw new ServiceException (e.getMessage());
		}
		
	}
	
	public long delete (int id) throws ServiceException {
		
		try {
			return vehiculedao.delete(id);
		} catch (DaoException e) {
			throw new ServiceException (e.getMessage());
		}
	}
}
