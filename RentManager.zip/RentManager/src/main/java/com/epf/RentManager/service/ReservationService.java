package com.epf.RentManager.service;

import java.time.temporal.ChronoUnit;
import java.util.List;

import com.epf.RentManager.dao.ReservationDao;
import com.epf.RentManager.exception.DaoException;
import com.epf.RentManager.exception.ServiceException;
import com.epf.RentManager.model.Reservation;

	public class ReservationService {
	
	private ReservationDao resdao;
	public static ReservationService instance;
	
	private ReservationService() {
		this.resdao = ReservationDao.getInstance();
	}
	
	public static ReservationService getInstance() {
		if (instance == null) {
			instance = new ReservationService();
		}
		
		return instance;
	}

	public long create(Reservation resa) throws ServiceException {
		// TODO: créer une réservation	
		long resMax = ChronoUnit.DAYS.between(resa.getDebut().toLocalDate(), resa.getFin().toLocalDate());
		if(resMax > 7) {
			throw new ServiceException("Une voiture ne peut pas être réservée plus de 7 jours.");
		}
		
		try {
			return resdao.create(resa);
		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}
	
	public void findResaByClientId(int clientId) throws ServiceException {
		// TODO: récupérer une réservation par l'id du client
		
		try {
			resdao.findResaByClientId(clientId);
		}
		catch (DaoException e) {
			throw new ServiceException (e.getMessage());
		}
	}
	
	public void findResaByVehicleId(int vehiculeId) throws ServiceException {
		// TODO: récupérer une réservation par l'id du véhicule

		try {
			resdao.findResaByVehicleId(vehiculeId);
		}
		catch (DaoException e) {
			throw new ServiceException (e.getMessage());
		}
	}
	
	public List<Reservation> findAll() throws ServiceException {
		// TODO: récupérer toutes les réservations	
		try {
			return resdao.findAll();
		} catch (DaoException e) {
			throw new ServiceException (e.getMessage());
		}
	}
	
	public long delete (int id) throws ServiceException {
		
		try {
			return resdao.delete(id);
		} catch (DaoException e) {
			throw new ServiceException (e.getMessage());
		}
	}
}
