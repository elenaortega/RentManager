package com.epf.RentManager.model;

public class Vehicule {
	private int id;
	private String constructeur;
	private String modele;
	private byte nb_places;
	
	public Vehicule() {
		
	}
	
	public Vehicule (int id, String constructeur, String modele, byte nb_places) {
		this.id = id;
		this.constructeur = constructeur;
		this.modele = modele;
		this.nb_places = nb_places;
	}

	@Override
	public String toString() {
		return "Vehicule [id=" + id + ", constructeur=" + constructeur + ", modele=" + modele + ", nb_places="
				+ nb_places + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getConstructeur() {
		return constructeur;
	}

	public void setConstructeur(String constructeur) {
		this.constructeur = constructeur;
	}

	public String getModele() {
		return modele;
	}

	public void setModele(String modele) {
		this.modele = modele;
	}

	public byte getNb_places() {
		return nb_places;
	}

	public void setNb_places(byte nb_places) {
		this.nb_places = nb_places;
	}
	
	
}
