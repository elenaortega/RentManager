package com.epf.RentManager.model;

import java.sql.Date;

public class Client {
	
	private int id;
	private String nom;
	private String prenom;
	private String email;
	private Date naissance;
	
	public Client() { //fonction pour laquelle on ne devra pas préciser de paramètres
		
	}
	
	public Client (int id, String prenom, String nom, String email, Date naissance) { //fonction pour laquelle il faut préciser tous les paramètres
		this.id = id;
		this.prenom = prenom;
		this.nom = nom;
		this.email = email;
		this.naissance = naissance; 
	}

	@Override // se crea con clic droit, source, generate toString()
	public String toString() { //fonction qui permet de renvoyer toutes les informations du client
		return "Client [id=" + id + ", nom=" + nom + ", prenom=" + prenom + ", email=" + email + ", naissance="
				+ naissance + "]";
	}

	//fonctions pour récupérer et set les différents paramètres
	//se crea con clic droit, source, generate getters and setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getNaissance() {
		return naissance;
	}

	public void setNaissance(Date naissance) {
		this.naissance = naissance;
	}
	
	
	
}